Connect
Release Date    : 12 May 2020
Author          : KodeMint
Author Email    : hi@kodemint.in
Skype           : KodeMint
Website         : https://kodemint.in
Support         : http://support.kodemint.in
Product Website : https://kodemint.in/connect
Demo            : https://connect.kodemint.in
--------------------------------------------

To read installation guidelines, please visit http://support.kodemint.in

Version 1.0.0 Released on 12 May 2020

* Initial Release