import Spinner from './Spinner.vue'
import SquareBounceRotate from './SquareBounceRotate.vue'

export default {
  Spinner,
  SquareBounceRotate,
}
