<?php

	/*
	|| #################################################################### ||
	|| #                             ArrowChat                            # ||
	|| # ---------------------------------------------------------------- # ||
	|| #    Copyright �2010-2012 ArrowSuites LLC. All Rights Reserved.    # ||
	|| # This file may not be redistributed in whole or significant part. # ||
	|| # ---------------- ARROWCHAT IS NOT FREE SOFTWARE ---------------- # ||
	|| #   http://www.arrowchat.com | http://www.arrowchat.com/license/   # ||
	|| #################################################################### ||
	*/

?>
				</div>
				<div class="clear"></div>
			</div>
			<div class="clear"></div>
		</div>
		<div style="height: 30px;"></div>
	</div>
</div>
<div class="install-footer">
	<a href="https://www.arrowchat.com/support/" target="_blank">Get Help</a> | <a href="https://www.facebook.com/ArrowChat/" target="_blank">Like us on Facebook</a><br />
	ArrowChat Version <?php echo ARROWCHAT_VERSION; ?>
</div>
<div style="height: 30px;"></div>
</body>
</html>