<div class="arrowchat_moderation_title">
	<div class="arrowchat_tab_name">'+lang[166]+'</div>
</div>
<div class="arrowchat_reports_subtitle"></div>
<div class="arrowchat_clearfix"></div>
<div class="arrowchat_moderation_content">
	<div id="arrowchat_moderation_flyout" class="arrowchat_message_box">
		<div class="arrowchat_message_box_wrapper">
			<div>
				<span class="arrowchat_message_text">'+lang[182]+'</span>
			</div>
		</div>
	</div>
	<div class="arrowchat_moderation_full_content">
	</div>
</div>