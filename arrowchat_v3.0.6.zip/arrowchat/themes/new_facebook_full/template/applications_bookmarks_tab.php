<div class="arrowchat_inner_button">
	<img class="arrowchat_tray_icon" src="'+c_ac_path+"applications/"+apps[b][2]+"/images/"+apps[b][3]+'" /><div class="arrowchat_app_button_name">' + apps[b][11] + '</div>
</div>