<?php

	/*
	 *  Leaf
	 *	Designed By: ArrowChat Team
	 *	Support: http://www.arrowchat.com/support/
	 *	
	 *	This file is for installation only, and can be deleted after the application is installed.
	 *
	 *  This application is designed for ArrowChat software (www.arrowchat.com).  ArrowChat is
	 *  NOT FREE SOFTWARE.  This application may or may not be free software.  If you have not
	 *  paid for this application, please verify it is free at the ArrowChat store
	 *  (www.arrowchat.com/store).  You must have an active ArrowChat license to install this
	 *  application.
	*/
	
	// REQUIRED
	// The application version.
	$theme_version = "4.1";
	
	// REQUIRED
	// Update link for the application.  Provided by ArrowChat.
	$update_link		= "http://www.arrowchat.com/updatecheck.php?id=36";

?>