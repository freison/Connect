<div class="arrowchat_inner_button">
	<div id="arrowchat_userstab_icon"></div>
	<div id="arrowchat_userstab_text" style="float:left"><b>'+lang[4]+'</b> (<b>0</b>)</div>
</div>