<li id="arrowchatapplist_'+apps[b][0]+'">
	<div>
		<a id="arrowchat_app_link_'+apps[b][0]+'" class="arrowchat_app_link" href="javascript:void(0);">
		<div style="float: left; height: 16px; overflow: hidden hidden; padding: 2px 5px; width: 16px;">
			<img style="height: 16px; width: 16px; border: 0px;" src="'+c_ac_path+"applications/"+apps[b][2]+"/images/"+apps[b][3]+'" />
		</div>
		<div style="padding-top: 2px;">'+apps[b][1]+'</div>
		</a>
	</div>
</li>