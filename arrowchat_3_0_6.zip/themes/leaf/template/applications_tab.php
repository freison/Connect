<div class="arrowchat_inner_button">
	<img class="arrowchat_tray_icon" src="'+c_ac_path+'themes/'+u_theme+'/images/icons/tray_arrowchat.png" />
	<div class="arrowchat_tray_name">'+lang[16]+'</div>
</div>