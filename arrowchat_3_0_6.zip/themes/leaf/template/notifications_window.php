<div class="arrowchat_userstabtitle">
	<div class="arrowchat_tab_name">'+lang[0]+'</div>
	<div class="arrowchat_see_all_button">
		<a href="javascript:void(0);" class="arrowchat_see_all_link arrowchat_more_anchor"></a>
	</div>
</div>
<div class="arrowchat_tabcontent arrowchat_optionstyle">
	<div id="arrowchat_notifications_content">
		<div id="arrowchat_no_new_notifications">'+lang[9]+'</div>
	</div>
</div>