<div id="arrowchat_warnings">
	<div class="arrowchat_warnings_content">
		<div class="arrowchat_warning_message"><div class="arrowchat_warning_icon"></div>'+lang[199]+'</div>
		<div class="arrowchat_warning_reason">'+h.data+'</div>
		<div class="arrowchat_warnings_close_div">
			<span class="arrowchat_warnings_close"><a href="javascript:void(0);">'+lang[198]+'</a></span>
		</div>
	</div>
	<div class="arrowchat_warnings_tip_pos"></div>
</div>