<div class="arrowchat_traytitle">
	<div class="arrowchat_tab_name">'+lang[16]+'</div>
</div>
<div class="arrowchat_apps_subtitle">'+lang[65]+'</div>
<div class="arrowchat_traycontent">
	<div style="height: auto; overflow: hidden hidden; position: relative;">
		<div>
			<div id="arrowchat_bookmarks"></div>
		</div>
	</div>
</div>