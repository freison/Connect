		</div>
		<div class="clear"></div>
		<div class="h-0" style="height: 40px;"></div>
		<div class="push"></div>
	</div>
</div>
<div class="footer">
	<div class="footercontent">
		<div style="float: left; padding-top:6px;">
			<a href="http://www.arrowchat.com" target="_blank">ArrowChat Website</a> &bull; <a href="http://www.arrowchat.com/support/" target="_blank">Support</a>
		</div>
		<div style="float: right; padding-top:6px;">
			Version <?php echo ARROWCHAT_VERSION; ?>
		</div>
	</div>
</div>
</body>
</html>