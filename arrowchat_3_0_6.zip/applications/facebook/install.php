<?php

	// Application Install File
	// This file will be called when the application is first installed

?>