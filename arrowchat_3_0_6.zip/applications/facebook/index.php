<?php

	require_once(dirname(__FILE__)."/config.php");

if (!empty($pageName)) 
{
echo <<<EOD
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="cache-control" content="no-cache">
	<meta http-equiv="pragma" content="no-cache">
	<meta http-equiv="expires" content="-1">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8"/> 
</head>

<body>

	<iframe src="//www.facebook.com/connect/connect.php?name={$pageName}&connections={$connections}&stream={$displayStream}&show_border=false&show_posts=true&width=394&height=400" width="394" height="400" scrolling="no" frameborder="0"></iframe>
	
</body>

</html>
EOD;
}
else
{
echo <<<EOD
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="cache-control" content="no-cache">
	<meta http-equiv="pragma" content="no-cache">
	<meta http-equiv="expires" content="-1">
	<meta http-equiv="content-type" content="text/html; charset=UTF-8"/> 
</head>

<body>

	<iframe src="//www.facebook.com/connect/connect.php?id={$pageId}&connections={$connections}&stream={$displayStream}&show_border=false&show_posts=true&width=394&height=400" width="394" height="400" scrolling="no" frameborder="0"></iframe>
	
</body>

</html>
EOD;
}

?>