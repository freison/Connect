<?php

// The page ID of your Facebook page.  Leave blank if you have a page like facebook.com/arrowchat
$pageId = '';

// The page name of your Facebook page.
$pageName = 'ArrowChat';

// Which stream to display
$displayStream = '1';

// The number of people to show that like your facebook page.
$connections = '6';

?>