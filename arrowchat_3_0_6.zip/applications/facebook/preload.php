<?php

	// Application Pre-load File
	// This file will be called when the bar is loaded
	// ONLY USE THIS FILE FOR SIMPLE NON INTENSIVE DATABASE OR JAVASCRIPT OPERATIONS

?>