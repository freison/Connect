<?php

	// ########################## INCLUDE BACK-END ###########################
	require_once (dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . 'cache' . DIRECTORY_SEPARATOR . 'data_admin_options.php');
	
	$path = $base_url . "includes/emojis/img/32/";

?>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>26bd.png" alt="" data-id="26bd.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3c0.png" alt="" data-id="1f3c0.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3c8.png" alt="" data-id="1f3c8.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>26be.png" alt="" data-id="26be.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3be.png" alt="" data-id="1f3be.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3c9.png" alt="" data-id="1f3c9.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3b1.png" alt="" data-id="1f3b1.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>26f3.png" alt="" data-id="26f3.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3bf.png" alt="" data-id="1f3bf.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3c2.png" alt="" data-id="1f3c2.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3a3.png" alt="" data-id="1f3a3.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f6a3.png" alt="" data-id="1f6a3.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3ca.png" alt="" data-id="1f3ca.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3c4.png" alt="" data-id="1f3c4.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f6b4.png" alt="" data-id="1f6b4.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f6b5.png" alt="" data-id="1f6b5.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3c7.png" alt="" data-id="1f3c7.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3c6.png" alt="" data-id="1f3c6.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3bd.png" alt="" data-id="1f3bd.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3ab.png" alt="" data-id="1f3ab.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3ad.png" alt="" data-id="1f3ad.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3a8.png" alt="" data-id="1f3a8.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3aa.png" alt="" data-id="1f3aa.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3a4.png" alt="" data-id="1f3a4.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3a7.png" alt="" data-id="1f3a7.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3bc.png" alt="" data-id="1f3bc.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3b9.png" alt="" data-id="1f3b9.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3b7.png" alt="" data-id="1f3b7.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3ba.png" alt="" data-id="1f3ba.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3b8.png" alt="" data-id="1f3b8.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3bb.png" alt="" data-id="1f3bb.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3ac.png" alt="" data-id="1f3ac.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3ae.png" alt="" data-id="1f3ae.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f47e.png" alt="" data-id="1f47e.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3af.png" alt="" data-id="1f3af.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3b2.png" alt="" data-id="1f3b2.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3b0.png" alt="" data-id="1f3b0.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f3b3.png" alt="" data-id="1f3b3.png" /></div>