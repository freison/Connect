<?php

	// ########################## INCLUDE BACK-END ###########################
	require_once (dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . 'cache' . DIRECTORY_SEPARATOR . 'data_admin_options.php');
	
	$path = $base_url . "includes/emojis/img/32/";

?>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f34f.png" alt="" data-id="1f34f.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f34e.png" alt="" data-id="1f34e.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f350.png" alt="" data-id="1f350.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f34a.png" alt="" data-id="1f34a.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f34b.png" alt="" data-id="1f34b.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f34c.png" alt="" data-id="1f34c.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f349.png" alt="" data-id="1f349.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f347.png" alt="" data-id="1f347.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f353.png" alt="" data-id="1f353.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f348.png" alt="" data-id="1f348.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f352.png" alt="" data-id="1f352.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f351.png" alt="" data-id="1f351.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f34d.png" alt="" data-id="1f34d.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f345.png" alt="" data-id="1f345.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f346.png" alt="" data-id="1f346.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f33d.png" alt="" data-id="1f33d.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f360.png" alt="" data-id="1f360.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f35e.png" alt="" data-id="1f35e.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f357.png" alt="" data-id="1f357.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f356.png" alt="" data-id="1f356.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f364.png" alt="" data-id="1f364.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f373.png" alt="" data-id="1f373.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f354.png" alt="" data-id="1f354.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f35f.png" alt="" data-id="1f35f.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f355.png" alt="" data-id="1f355.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f35d.png" alt="" data-id="1f35d.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f35c.png" alt="" data-id="1f35c.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f372.png" alt="" data-id="1f372.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f365.png" alt="" data-id="1f365.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f363.png" alt="" data-id="1f363.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f371.png" alt="" data-id="1f371.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f35b.png" alt="" data-id="1f35b.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f359.png" alt="" data-id="1f359.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f35a.png" alt="" data-id="1f35a.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f358.png" alt="" data-id="1f358.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f362.png" alt="" data-id="1f362.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f361.png" alt="" data-id="1f361.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f367.png" alt="" data-id="1f367.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f368.png" alt="" data-id="1f368.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f366.png" alt="" data-id="1f366.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f370.png" alt="" data-id="1f370.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f36f.png" alt="" data-id="1f36f.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f382.png" alt="" data-id="1f382.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f36e.png" alt="" data-id="1f36e.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f36c.png" alt="" data-id="1f36c.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f36d.png" alt="" data-id="1f36d.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f36b.png" alt="" data-id="1f36b.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f369.png" alt="" data-id="1f369.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f36a.png" alt="" data-id="1f36a.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f37a.png" alt="" data-id="1f37a.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f37b.png" alt="" data-id="1f37b.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f377.png" alt="" data-id="1f377.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f378.png" alt="" data-id="1f378.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f379.png" alt="" data-id="1f379.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f376.png" alt="" data-id="1f376.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f375.png" alt="" data-id="1f375.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>2615.png" alt="" data-id="2615.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f37c.png" alt="" data-id="1f37c.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f374.png" alt="" data-id="1f374.png" /></div>