<?php

	// ########################## INCLUDE BACK-END ###########################
	require_once (dirname(dirname(dirname(__FILE__))) . DIRECTORY_SEPARATOR . 'cache' . DIRECTORY_SEPARATOR . 'data_admin_options.php');
	
	$path = $base_url . "includes/emojis/img/32/";

?>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f1fa-1f1f8.png" alt="" data-id="1f1fa-1f1f8.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f1ee-1f1f9.png" alt="" data-id="1f1ee-1f1f9.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f1e9-1f1ea.png" alt="" data-id="1f1e9-1f1ea.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f1ec-1f1e7.png" alt="" data-id="1f1ec-1f1e7.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f1eb-1f1f7.png" alt="" data-id="1f1eb-1f1f7.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f1ea-1f1f8.png" alt="" data-id="1f1ea-1f1f8.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f1f7-1f1fa.png" alt="" data-id="1f1f7-1f1fa.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f1e8-1f1f3.png" alt="" data-id="1f1e8-1f1f3.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f1ef-1f1f5.png" alt="" data-id="1f1ef-1f1f5.png" /></div>
<div class="arrowchat_emoji"><img src="<?php echo $path; ?>1f1f0-1f1f7.png" alt="" data-id="1f1f0-1f1f7.png" /></div>