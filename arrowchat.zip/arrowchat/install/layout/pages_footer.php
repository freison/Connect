<?php

	/*
	|| #################################################################### ||
	|| #                             ArrowChat                            # ||
	|| # ---------------------------------------------------------------- # ||
	|| #    Copyright �2010-2012 ArrowSuites LLC. All Rights Reserved.    # ||
	|| # This file may not be redistributed in whole or significant part. # ||
	|| # ---------------- ARROWCHAT IS NOT FREE SOFTWARE ---------------- # ||
	|| #                ArrowChat Nulled                             # ||
	|| #################################################################### ||
	*/

?>
				</div>
				<div class="clear"></div>
			</div>
			<div class="button_container float">
				<div class="floatr">
					<a class="fwdbutton" <?php echo $next[1]; ?>>
						<span><?php echo $next[0]; ?></span>
					</a>
				</div>
			</div>
			<div class="clear"></div>
		</div>
		<div style="height: 30px;"></div>
	</div>
</div>
<div class="install-footer">
	ArrowChat Software
</div>
<div style="height: 30px;"></div>
</body>
</html>