<div class="arrowchat_inner_button">
	<div id="arrowchat_chatrooms_icon"></div>
	<div id="arrowchat_chatrooms_text" style="float:left">' + lang[19] + '</div>
</div>