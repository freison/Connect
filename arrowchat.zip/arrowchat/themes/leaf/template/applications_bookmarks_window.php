<div class="arrowchat_traytitle">
	<div class="arrowchat_tab_name">'+apps[b][1]+'</div>
	<div class="arrowchat_more_button">
		<a href="javascript:void(0)" class="arrowchat_more_anchor" id="arrowchat_apps_more_'+apps[b][0]+'"></a>
		<div class="arrowchat_more_wrapper_left">
			<div id="arrowchat_apps_more_popout_'+apps[b][0]+'" class="arrowchat_more_popout">
				<ul class="arrowchat_inner_menu">
					<li class="arrowchat_menu_item">
						<a id="arrowchat_app_keep_open_'+apps[b][0]+'" class="arrowchat_menu_anchor arrowchat_app_keep_open">
							<input type="checkbox" checked="" />
							<span>'+lang[104]+'</span>
						</a>
					</li>
					<!--<li class="arrowchat_menu_item">
						<a id="arrowchat_app_load_'+apps[b][0]+'" class="arrowchat_menu_anchor arrowchat_app_load">
							<input type="checkbox" checked="" />
							<span>'+lang[105]+'</span>
						</a>
					</li>-->
				</ul>
				<i class="arrowchat_more_tip_left"></i>
			</div>
		</div>
	</div>
</div>
<div class="arrowchat_traycontent">
	<div class="arrowchat_traycontenttext">
		<div id="arrowchat_applications_button_'+apps[b][0]+'_content" style="width: '+apps[b][4]+'px;">
			<div class="arrowchat_loader"></div>
		</div>
	</div>
</div>