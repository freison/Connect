<div id="arrowchat_report_history">
	<div id="arrowchat_report_history_content"></div>
</div>
<div id="arrowchat_report_info">
	<div class="arrowchat_report_info_about"></div>
	<div class="arrowchat_report_info_from"></div>
	<div class="arrowchat_report_info_warnings"></div>
	<div class="arrowchat_report_info_time"></div>
</div>
<div id="arrowchat_report_list">
	<div id="arrowchat_report_line" class="arrowchat_group_container">
		<span class="arrowchat_group_text">'+lang[181]+'</span>
		<div class="arrowchat_group_line_container">
			<span class="arrowchat_group_line"></span>
		</div>
	</div>
	<div id="arrowchat_list_reports"></div>
</div>
<div class="arrowchat_clearfix"></div>