<div id="arrowchat_announcement">
	<div class="arrowchat_announcement_content">
		'+h.data+'
		<div class="arrowchat_announce_close_div">
			<span class="arrowchat_announce_close"><a href="javascript:void(0);">'+lang[28]+'</a></span>
		</div>
	</div>
	<div class="arrowchat_announcement_tip_pos"></div>
</div>