<div class="arrowchat_inner_button">
	<div style="float:left" class="arrowchat_username_message">'+shortname+'</div>
</div>
<div class="arrowchat_closebox_bottom"></div>
<div class="arrowchat_is_typing"><div class="arrowchat_typing_bubble"></div><div class="arrowchat_typing_bubble"></div><div class="arrowchat_typing_bubble"></div></div>