<?php

	/*
	 *  Facebook
	 *	Designed By: ArrowChat Team
	 *	
	 *	This file is for installation only, and can be deleted after the application is installed.
	 *
	 *  This application is designed for ArrowChat software .  ArrowChat is
	 *  NOT FREE SOFTWARE.  This application may or may not be free software.  If you have not
	 *  paid for this application, please verify it is free at the ArrowChat store
	 *  You must have an active ArrowChat license to install this
	 *  application.
	*/
	
	// REQUIRED
	// The application version.
	$theme_version = "6.1";
	
	// REQUIRED
	// Update link for the application.  Provided by ArrowChat.
	$update_link		= "";

?>