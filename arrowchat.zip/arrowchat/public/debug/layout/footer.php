<?php

	/*
	|| #################################################################### ||
	|| #                             ArrowChat                            # ||
	|| # ---------------------------------------------------------------- # ||
	|| #    Copyright �2010-2012 ArrowSuites LLC. All Rights Reserved.    # ||
	|| # This file may not be redistributed in whole or significant part. # ||
	|| # ---------------- ARROWCHAT IS NOT FREE SOFTWARE ---------------- # ||
	|| #                ArrowChat Nulled                             # ||
	|| #################################################################### ||
	*/

?>
				</div>
				<div class="clear"></div>
			</div>
			<div class="clear"></div>
		</div>
		<div style="height: 30px;"></div>
	</div>
</div>
<div class="install-footer">
	ArrowChat Version <?php echo ARROWCHAT_VERSION; ?>
</div>
<div style="height: 30px;"></div>
</body>
</html>