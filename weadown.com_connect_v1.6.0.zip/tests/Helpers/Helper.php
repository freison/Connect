<?php

namespace Tests\Helpers;

use App\Models\User;

class Helper
{
    // public static function generateUser($data = []) : User
    // {
    //     return User::factory()->create($data);
    // }
}