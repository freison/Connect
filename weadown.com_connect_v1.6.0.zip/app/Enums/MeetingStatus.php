<?php

namespace App\Enums;

class MeetingStatus
{
    const SCHEDULED = 'scheduled';
    const CANCELLED = 'cancelled';
    const LIVE = 'live';
    const ENDED = 'ended';
}
