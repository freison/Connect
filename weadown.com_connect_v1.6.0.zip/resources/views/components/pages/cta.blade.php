<!-- ======= CTA Section ======= -->
<section id="cta" class="cta">
<div class="container" data-aos="fade-up">

    <div class="section-content d-flex justify-content-between align-items-center">
        <div data-aos="fade-right" data-aos-delay="200">
            <h2>Collaborate online in real-time</h2>
            <p>With Video, Audio and Screen Sharing Communication, and Live Chat</p>
        </div>
        <a href="/app/panel/dashboard" class="btn-buy" data-aos="fade-left" data-aos-delay="200">Get Started</a>
    </div>

</div>
</section><!-- End CTA Section -->