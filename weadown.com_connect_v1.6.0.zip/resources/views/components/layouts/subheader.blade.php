@props(['heading' => 'home'])

<!-- ======= Sub Header Section ======= -->
<section id="subheader" class="subheader">
<div class="container">

    <div class="section-title d-flex justify-content-center align-items-center">
        <div>
            <h2>{{ $heading }}</h2>
        </div>
    </div>

</div>
</section><!-- End Sub Header Section -->