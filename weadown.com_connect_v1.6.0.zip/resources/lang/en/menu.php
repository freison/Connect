<?php return array (
  'menu' => 'Menu',
  'extras' => 'Extras',
  'internals' => 'Internals',
  'master' => 'Master',
  'primary' => 'Primary',
  'setup' => 'Setup',
  'utilities' => 'Utilities',
);
