<?php
return array(
    'dashboard' => 'Dashboard',
    'hello' => 'Hello',
    'chart' => 'Chart',
    'nothing_to_show' => 'All clear, nothing to show!',
    'stats' => array(
        'total' => 'Total :attribute',
        'count' => ':attribute Count',
        'today' => ':attribute Today',
    ),
);
