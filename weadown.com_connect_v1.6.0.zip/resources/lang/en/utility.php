<?php return array (
  'backup' =>
  array (
    'backup' => 'Backup',
    'deleted' => 'Backup deleted.',
    'download' => 'Download Backup',
    'generated' => 'Backup generated.',
    'generated_at' => 'Generated at',
    'list' => 'Backup List',
    'module_description' => 'Never loose your database. Schedule daily backups, download backup.',
    'module_title' => 'Create daily backups here!',
    'name' => 'Name',
  ),
  'todo' =>
  array (
    'todo' => 'Todo',
    'todos' => 'Todos',
    'tasks' => 'Tasks',
    'props' =>
    array (
      'date' => 'Date',
      'time' => 'Time',
      'description' => 'Description',
      'title' => 'Title',
      'status' => 'Status',
    ),
    'completed_at' => 'Completed at',
    'due_on' => 'Due on',
    'complete' => 'Complete',
    'completed' => 'Completed',
    'incomplete' => 'In-complete',
    'list' => 'Todo List',
    'type_task' => 'Type task here and press enter...',
    'all_caught_up' => 'All Caught Up!',
    'mark_as_complete' => 'Mark as Complete',
    'mark_as_incomplete' => 'Mark as In-complete',
    'module_description' => 'Never miss your todo list. Add all your todos here. Keep record of compelte, incompelte todo list.',
    'show_completed' => 'Show Completed',
  ),
  'utility' => 'Utility',
);
