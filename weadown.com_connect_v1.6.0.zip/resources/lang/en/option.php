<?php return array (
    'option' => 'Option',
    'options' => 'Options',
    'props' =>
    array (
      'name' => 'Name',
      'slug' => 'Slug',
      'type' => 'Type',
      'parent' => 'Parent',
      'description' => 'Description',
    ),
);
