<?php return array (
  'next' => 'Next &raquo;',
  'pagination' => 'Pagination',
  'previous' => '&laquo; Previous',
);